export class BreedDTO {
    breed_name: string;
    breed_wiki_link: string;
}
