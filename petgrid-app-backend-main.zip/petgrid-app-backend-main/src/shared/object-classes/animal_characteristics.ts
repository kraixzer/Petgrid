export class AnimalCharacteristics {
    name: string;
    value: string;
}
