export class AnimalSpecifics {
    name: string;
    value: string;
}
