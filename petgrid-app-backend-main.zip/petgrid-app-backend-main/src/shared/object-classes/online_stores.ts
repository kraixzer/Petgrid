export class OnlineStores {
    name: string;
    url: string;
}
